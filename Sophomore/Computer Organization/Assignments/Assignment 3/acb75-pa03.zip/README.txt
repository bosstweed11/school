Andrew Beers
acb75@pitt.edu
Project 3
README file

I have tested all of the test files against my processor design, and all but 2 seem to work as expected. The load.asm doesn't seem to work as expected, although the loadstore.asm does work so this is unexpected. Lastly the function.asm performs as expected although it returns to the beginning of the program,instead of the return register, resulting in an infinite loop. Aside from this my design seems fully functional for all basic commands required for this project. 


